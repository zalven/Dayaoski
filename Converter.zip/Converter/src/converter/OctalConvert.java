
package converter;

import java.util.HashMap;
import java.util.Map;

public class OctalConvert {
    public static Map<String,String> octalVal = new HashMap<>();
    OctalConvert(){
        octalVal.put("0","000"); octalVal.put("4","100");
        octalVal.put("1","001"); octalVal.put("5","101");
        octalVal.put("2","010"); octalVal.put("6","110");
        octalVal.put("3","011"); octalVal.put("7","111");}
    
    
    public static String OctalToBinary(String octal){
        new OctalConvert();
        String WholeNum = "";
        String DeciNum = "";
        if(octal.equals("")||!octal.matches("^[0-7.]*$"))
            return "";      
        String sep[] = octal.split("\\.");
        for(String octals:sep[0].split(""))WholeNum+=(octalVal.get(octals));

        if(octal.contains (".") && sep.length != 1){  
            for(String octals:sep[1].split(""))DeciNum +=(octalVal.get(octals));
            DeciNum = (new StringBuilder(DeciNum).reverse().toString()).replaceFirst ("^0*", "");
            DeciNum = "."+new StringBuilder(DeciNum).reverse().toString();}  
        return WholeNum.replaceFirst ("^0*", "")+DeciNum;}
     
    public static String OctalToDecimal(String octal){
        new OctalConvert();
        int wholeResult = 0;
        double DecimalResult = 0;
        String res = "";
        if(octal.equals("")||!octal.matches("^[0-7.]*$"))
            return "";    
        String sep[] = octal.split("\\.");
        sep[0] = new StringBuilder(sep[0]).reverse().toString();
        for(int i = 0 ; i < sep[0].length();i++)
            wholeResult += Integer.parseInt(sep[0].charAt(i)+"")*Math.pow(8, i);
    
        if(octal.contains (".") && sep.length != 1){  
             for(int i = 0 ; i < sep[1].length();i++)
                 DecimalResult += (Integer.parseInt(sep[1].charAt(i)+"")*Math.pow(8, -(i+1)));
             res = "."+((DecimalResult+"").split("\\.")[1]);}
        return wholeResult+""+res;}
    
    public static String OctalToHexa(String octal){
        if(octal.equals("")||!octal.matches("^[0-7.]*$"))
            return "";
        BinaryConvert  obj = new BinaryConvert();
        return  new BinaryConvert().binaryToHexaDecimal(OctalToBinary(octal));
    } 
}
