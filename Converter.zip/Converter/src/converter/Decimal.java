
package converter;



import java.util.HashMap;
import java.util.Map;

public class Decimal {
    public static Map<String,String> hexVal = new HashMap<>();
    Decimal(){
        hexVal.put("0", "0"); hexVal.put("8", "8");
        hexVal.put("1", "1"); hexVal.put("9", "9");
        hexVal.put("2", "2"); hexVal.put("10", "A");
        hexVal.put("3", "3"); hexVal.put("11", "B");
        hexVal.put("4", "4"); hexVal.put("12", "C");
        hexVal.put("5", "5"); hexVal.put("13", "D");
        hexVal.put("6", "6"); hexVal.put("14", "E");
        hexVal.put("7", "7"); hexVal.put("15", "F");}
    
    public static String DecimalToHexa(String decimal){
        new Decimal();
         if(decimal.equals("")||!decimal.matches("^[0-9.]*$"))
            return "";
        
        String wholeNum = "";
        String DecimalP = "";
        String[] deci = decimal.split("\\.");
         
        for(int number = Integer.parseInt(deci[0]) ; number >=1 ;number = (int)number/16)
            wholeNum =  hexVal.get(number%16+"")+wholeNum;
    
        if(decimal.contains(".")&&  deci.length != 1){
            String breaks = "";
            double number = Double.parseDouble("0."+deci[1]);
            while(true){
                String[] nums = (""+number).split("\\.");
                number = Double.parseDouble("."+nums[1])*16;
   
                if(breaks.contains(nums[1]))
                    break;
                breaks += ","+nums[1];
                DecimalP += hexVal.get(nums[0]);}
            DecimalP = "."+(DecimalP.substring(1));}
        return wholeNum+DecimalP ;}
    
    
    public static String DecimalToOctal(String decimal){
        if(decimal.equals("")||!decimal.matches("^[0-9.]*$"))
            return "";

        String wholeNum = "";
        String DecimalP = "";
        String[] deci = decimal.split("\\.");
    
        for(int number = Integer.parseInt(deci[0]) ; number >=1 ;number = (int)number/8)
            wholeNum = (number%8)+wholeNum;
 
        if(decimal.contains(".")&&  deci.length != 1){
            String breaks = "";
            double number = Double.parseDouble("0."+deci[1]);
            while(true){
                String[] nums = (""+number).split("\\.");
                number = Double.parseDouble("0."+nums[1])*8;
                if(breaks.contains(nums[1]))
                    break;
                breaks += ","+nums[1];
                DecimalP += nums[0];}
            DecimalP = "."+(DecimalP.substring(1));}
        
        return wholeNum+DecimalP ;}
    
    

    public static String DecimalToBinary(String num){
      
        if(num.equals("")||!num.matches("^[0-9.]*$"))
            return "";
        String wholeNum = "";
        String DecimalP = "";
        String[] decimal = num.split("\\.");
         
        for(int number = Integer.parseInt(decimal[0]) ; number >=1 ;number = (int)number/2)
            wholeNum = (number%2)+wholeNum;
        
        if(num.contains(".")&&  decimal.length != 1){
            String breaks = "";
            double number = Double.parseDouble("0."+decimal[1]);
            while(true){
                String[] nums = (""+number).split("\\.");
                number = Double.parseDouble("0."+nums[1])*2;
                if(breaks.contains(nums[1]))
                    break;
                breaks += ","+nums[1];
                DecimalP += nums[0];}
            DecimalP = "."+(DecimalP.substring(1));}

        return wholeNum+DecimalP;}

}
