package converter;

import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;
public class BinaryConvert {
    
    public static Map<String,String> octalValues = new HashMap<>();
    public static Map<String,String> hexValues = new HashMap<>();
    public static DecimalFormat octalNumFormat = new DecimalFormat("#,###");
    public static DecimalFormat hexNumFormat = new DecimalFormat("#,####");
    
    
    
    BinaryConvert(){
        // we use hashmap for easy conversion that takes max of 3 values
        octalValues.put("000", "0"); octalValues.put("101", "5");
        octalValues.put("001", "1"); octalValues.put("110", "6");
        octalValues.put("010", "2"); octalValues.put("111", "7");
        octalValues.put("011", "3");
        octalValues.put("100", "4");
        
        hexValues.put("0000", "0"); hexValues.put("1010", "A");
        hexValues.put("0001", "1"); hexValues.put("1011", "B");
        hexValues.put("0010", "2"); hexValues.put("1100", "C");
        hexValues.put("0011", "3"); hexValues.put("1101", "D");
        hexValues.put("0100", "4"); hexValues.put("1110", "E");
        hexValues.put("0101", "5"); hexValues.put("1111", "F");
        hexValues.put("0110", "6");
        hexValues.put("0111", "7");
        hexValues.put("1000", "8");
        hexValues.put("1001", "9");}
    
    public static String splitem(String n,int x,boolean rev){
        String result = "";
        
        int count = 0 ;
        for(int i = n.length()-1 ; i>=0 ;i--){
            result += n.charAt(count++)+"";
            if(i%(x)==0)result +=",";}
   
        return result;
    }
    public static String binaryToHexaDecimal(String bin){
        
        if(bin.equals("")||!bin.matches("^[0-1.]*$"))
            return "";
        
        new BinaryConvert();
        
        String wholeNumRes = "";
        String  decNumRes = "";
        String[] wholeNumBin = bin.split("\\.");
                              
        String numberAsString = splitem(wholeNumBin[0],4,false);
        System.out.println(numberAsString);
        for(String binaries:numberAsString.split(","))
            wholeNumRes += hexValues.get(String.format("%04d", Integer.parseInt(binaries)));
        
        if(bin.contains (".") &&  wholeNumBin.length != 1){    
            for(String binaries :wholeNumBin[1].split("(?<=\\G....)"))
               {
                if(binaries.length()==1)binaries+="000";
                if(binaries.length()==2)binaries+="00";
                if(binaries.length()==3)binaries+="0";
                //decNumRes
                decNumRes  += hexValues.get(binaries);}
            decNumRes = "."+decNumRes;}

            return wholeNumRes+decNumRes;}
    
    
    

    public static String binaryToOctal(String bin){
        // empty bin will cause an error

        if(bin.equals("")||!bin.matches("^[0-1.]*$"))
            return "";
        
        new BinaryConvert();
        String wholeNumRes = "";
        String decNumRes = "";
 
        //SplitBothNumbers with a dot for decimal points
        String[] wholeNumBin = bin.split("\\.");


        /** split using commas [WHOLE NUMBERS] =============================
         * for whole numbers only
         * iteration for whole numbers
         * fill Leading zeros 
        **/
        String numberAsString = splitem(wholeNumBin[0],3,false);
        System.out.println(numberAsString);
        for(String binaries:numberAsString.split(","))
            wholeNumRes += octalValues.get(String.format("%03d", Integer.parseInt(binaries)));
        
        /**
         * For Decimal Points only[Decimal Places] =========================
         * fill trailing zeros java
        **/
        
        if(bin.contains (".") &&  wholeNumBin.length != 1){
            for(String binaries :wholeNumBin[1].split("(?<=\\G...)")){
                if(binaries.length()==1)binaries+="00";
                if(binaries.length()==2)binaries+="0";
                //decNumRes
                decNumRes  += octalValues.get(binaries);}
            decNumRes = ("."+decNumRes);
            
        }
        return wholeNumRes+decNumRes;}
   
    public static String binaryToDecimal(String bin){
        if(bin.equals("")||!bin.matches("^[0-1.]*$"))
            return "";
        if(bin.equals(""))
            return "";
        //result
        int WholeNumResult =0;
        double DecimalResult =0;
        String deci = "";
       //seperate decimal point and whole number
       String[] seperator = bin.split("\\.");
       //reverse the Whole Numbers
       seperator[0] = new StringBuilder(seperator[0]).reverse().toString();
       // iteration for whole number
       for(int i = 0 ; i < seperator[0].length() ; i++)
                if(seperator[0].substring(i,i+1).equals("1"))
                    WholeNumResult += 1*Math.pow(2, i);
       // Decimal points
       if(bin.contains (".") && seperator.length != 1){
           for(int i = 1 ; i < seperator[1].length() +1 ; i++)
               if(seperator[1].substring(i-1,i).equals("1"))
                    DecimalResult += (Math.pow(2, -i));
            deci = "."+(DecimalResult+"").replace("0.","");}
       return(WholeNumResult+deci);}
    


    
    
    
    
}
